package ExercicioRevisao.entidades;

public class Pontinhos {
    
}
