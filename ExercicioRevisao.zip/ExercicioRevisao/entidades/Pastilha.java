package ExercicioRevisao.entidades;

public class Pastilha {
    
}
