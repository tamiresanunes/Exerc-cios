package ExercicioRevisao.entidades;

public class Objeto {
    
}
